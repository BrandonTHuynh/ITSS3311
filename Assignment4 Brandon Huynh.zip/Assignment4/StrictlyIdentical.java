/* Sample Runs
Enter the five integers in the first array list: 1 2 3 4 5
Enter the five integers in the second array list: 1 2 3 4 5
The Two lists are strictly identical

Enter the five integers in the first array list: 1 2 3 4 5
Enter the five integers in the second array list: 1 2 3 4 6
The Two lists are not strictly identical
 */
import java.util.Scanner;

public class StrictlyIdentical {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
	    
	System.out.print("Enter the five integers in the first array list: "); //This line prompts the user to input the 5 integers of the first list they want to compare
	    int[] list1 = new int[5]; //Caps the integer input to 5 integers
	    for (int i = 0; i < 5; i++) { //For loop to check integer entries and store them in list1
	        list1[i] = input.nextInt(); //This line allows the user to input the integers in the list and stores it in list1
	    }
	System.out.print("Enter the five integers in the second array list: ");//This line prompts the user to input the 5 integers of the second list they want to compare
	    int[] list2 = new int[5]; //Caps the integer input to 5 integers
	    for (int i = 0; i < 5; i++) { //For loop to check integer entries and store them in list2
	        list2[i] = input.nextInt(); //This line allows the user to input the integers in the list and stores it in list2
	    }
	    input.close(); //Closes the input to conclude the user inputting the two lists.

	    if (equals(list1,list2)) { //Boolean method equals on the two lists
	        System.out.println("The Two lists are strictly identical"); //This if statement prints if the integers in the two lists are completely identical
	    } 
	    else { //if not equal, the following line will print.
	        System.out.println("The Two lists are not strictly identical"); //This else statement prints if the integers in the two lists are NOT completely identical
	    }
	}
	
public static boolean equals(int[]list1,int[]list2) { //This is the equals method that compares the two lists based on the size of the array
	int[] array1 = list1; //This line uses a new variable (array1) and stores the content of list1 inside the new variable (reference).
	int[] array2 = list2; //This line uses a new variable (array2) and stores the content of list2 inside the new variable (reference).
	
	    for (int i = 0; i < 5; i++) { //When the criteria of this for loop is met, the for loop with carry out the if statement in the line below.
	        if (array1[i] != array2[i]) { //Conditional statement of not equal, if array1 is not equal to array2, the if statement returns false.
	            return false;
	        }
	    }

	    return true; //If the arrays are equal, the boolean returns true
	}

}

